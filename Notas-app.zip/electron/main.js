const {app,BrowserWindow}=require('electron');const path=require('path');
function create(){const w=new BrowserWindow({width:1280,height:850,title:'Notas',autoHideMenuBar:true,icon:path.join(__dirname,'../icons/icon-512.png')});w.loadFile(path.join(__dirname,'../index.html'))}
app.whenReady().then(create);app.on('window-all-closed',()=>app.quit());
